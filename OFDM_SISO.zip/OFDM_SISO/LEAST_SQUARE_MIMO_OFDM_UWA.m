clear;
%--------------------------------------------------
% Channel parameter
%--------------------------------------------------
load pdp_Halong_150m.mat;           % load dữ liệu đo PDP (công suất tín hiệu theo trễ)
Ni_1 = 40;          % Số điểm phản xạ mặt trên
Ni_2 = 40;          % Số điểm phản xạ mặt dưới
load x_opt_time_SISO_D_250m.mat;            % load vị trí điểm phản xạ đã tối ưu
x_suf_1 = x(1:Ni_1);
x_bot_1 = x(Ni_1+1:Ni_2+Ni_1);
y_1 = 20;			% Khoảng cách giữa anten với mặt nước
y_2 =30;			% Khoảng cách giữa anten với mặt đáy
lamda = 0.125;			% Độ dài bước sóng
c_s = 1500; 			% sound speed
D = 250;    			% distance
fD = 4;				% Tần số Dopppler
B = 500;			% Băng thông tương ứng với tốc độ lấy mẫu
% Tinh tre
D_T = ((y_1 ).^2+ x_suf_1.^2).^(1/2);
D_R = ((y_1 ).^2+ (D-x_suf_1).^2).^(1/2);
D_tau = D_T + D_R;
tau_suf = D_tau ./c_s; 
D_T = ((y_2 ).^2+ x_bot_1.^2).^(1/2);
D_R = ((y_2).^2+ (D-x_bot_1).^2).^(1/2);
D_tau = D_T + D_R;
tau_bot = D_tau ./c_s;
tau_all = [tau_suf,tau_bot];
tau_all_after = tau_all - min(tau_all);
N_P = round(max(tau_all_after)/(1/B)) + 1; 			% Sô đường trong kênh truyền
%--------------------------------
% System parameters
%--------------------------------
G = N_P;			% Độ dài khoảng bảo vệ
NFFT =128; 			% Số sóng mang con - số điểm FFT
M_ary =4;                % Multilevel of M-ary symbol
P_A = sqrt(2);           % Amplitude of pilot symbol
D_f = 2;                 % Pilot distance in frequency domain
D_t = 2;                 % pilot distance in time domain
NofZeros = D_f-1;		 % Số điểm không trong miền thời gian
M = NFFT / (D_f);        % Number of pilot symbol  per OFDM symbol
t_a = 1/B;       		% Sampling duration of HiperLAN/2
%-------------------------------------------------
% Parameters for Monte Carlo channel
%-------------------------------------------------
symbol_duration = NFFT * t_a;   %OFDM symbol duration
NofOFDMSymbol = 30;        %Number of data and pilot OFDM symbol
No_Of_OFDM_Data_Symbol = NofOFDMSymbol-ceil(NofOFDMSymbol/D_t); % Number of data symbols                         
length_data = (No_Of_OFDM_Data_Symbol) * NFFT;   % The total data length
Number_Relz = 30;			% Số lần lặp
ber_relz_e = [];			
ber_relz_ideal = [];
for number_of_relialization= 1: Number_Relz   
	teta=2*pi*rand(1,Ni_1+Ni_2); 			% Pha ngẫu nhiên (Nếu NLOS thì số thành phần là Ni_1+Ni_2, còn nếu là LOS thì số thành phần là Ni_1+Ni_2)
	%-------------
	% Source bites
	%-------------
	source_data = randi([0 1],length_data,log2(M_ary));			% Dữ liệu truyền đi
	%--------------------
	% bit to symbol coder
	%--------------------
	symbols = bi2de(source_data);  
	%----------------------------
	% QAM modulator in base band
	%----------------------------------------------
	QASK_Symbol = qammod(symbols,M_ary);
	%-----------------------------------------------
	% Preparing data pattern
	%-----------------------------------------------
	Data_Pattern = []; % Transmitted Signal before IFFT
	m = 0;
	for i=0:No_Of_OFDM_Data_Symbol-1;
		QASK_tem = [];
		for n=1:NFFT;
			QASK_tem = [QASK_tem,QASK_Symbol(i*NFFT+n)];
		end;
		Data_Pattern = [Data_Pattern;QASK_tem];
		clear QASK_tem;
	end;
		%------------------------
		% Preparing pilot pattern for Antenna
		%------------------------
	PP_A = [];
	for m = 0:M-1; 
		PP_A = [PP_A,P_A*exp(j*D_f*pi*(m)^2/NFFT)];  
		for l = 1:D_f -1;
			PP_A=[PP_A,zeros(1,NofZeros)]; 
		end;
	end;
	%----------------------------------------
	% FFT matrix
	%----------------------------------------
	F = [];
	for k=0:NFFT-1
		W_tem = [];
		for n = 0:NFFT-1;
			W_tem = [W_tem,exp(-j*2*pi*n*k/NFFT)];
		end;
		F = [F;W_tem];
	end;
	%---------------------------------------
	% Least square filter coefficients
	%---------------------------------------
	PP = [diag(PP_A)*F(:,1:N_P)];
	Q = inv(PP'*PP);
	%******************************************************************
	% Transmitted Signal of Antenna  (Inbert pilot sequence into data
	% sequence)
	%------------------------------------------------------------------
	TS_BeforeIFFT = Inbert_PilotSymbol(PP_A,Data_Pattern,D_t,NofOFDMSymbol,NFFT);
	ber_without_isic_e = [];
	ber_without_isic_ideal = [];
	snr_min =0;
	snr_max =30;
	step = 5;
	for snr = snr_min:step:snr_max; 
		rs_frame = [];			% Frame tín hiệu thu được
		h_frame = [];			% frame của kênh lý tưởng
		t=0.1;                 	% Initial time

		for i=0:NofOFDMSymbol-1;
		OFDM_signal_tem = OFDM_Modulator(TS_BeforeIFFT(i+1,:),NFFT,G);
		% OFDM signal from the  transmitt antenna is created
		[h] = UnderWaterChannel_SISO_NLOS(t,teta,D,fD,rho,tau,Ni_1,Ni_2,y_1,y_2,y_1,y_2,x_suf_1,x_bot_1,B);			% Kênh SISO NLOS
		%[h] = UnderWaterChannel_SISO_LOS(t,teta,D,fD,rho,tau,Ni_1,Ni_2,y_1,y_2,y_1,y_2,x_suf_1,x_bot_1,B);			% Kênh SISO LOS
		h_frame = [h_frame;h];
		rs = conv(OFDM_signal_tem, h);				% Cho tín hiệu qua kênh
		rs = awgn(rs,snr,'measured','dB');			% Công nhiễu trắng
		rs_frame = [rs_frame; rs];
		t = t+ symbol_duration;					% Tính thời gian sau 1 symbol_duration
		end;
		%-----------------
		% Receiver: OFDM demodulator, channel estimation
		%-----------------
		estimated_h = [];
		Received_PP= []; % Prepare a matrix for reveived pilot symbols
		Receiver_Data = []; %  Prepare a matrix for reveived data symbols
		SignalPostFFT = [];
		d_e = []; % Received signal of the receive antenna for esimated channel
		d_ideal = []; % Received signal of the  receive antenna for ideal channel
		data_symbol_e = [];
		data_symbol_ideal = [];
		for i=1:NofOFDMSymbol;
		if (N_P > G+1) & (i>1)
			% if it is not the  symbol and the length of CIR is longer than
			% the gaurd interval length, then the ISI term must be taken into 
			% account
			previous_symbol = rs_frame(i-1,:);
			% previous OFDM symbol of the  transmitt
			% antenna to the  receive antenna       
			ISI_term = previous_symbol11(NFFT+2*G+1:NFFT+G+N_P-1); 
			% the position from NFFT+2G+1: NFFT+G+N_P-1 is ISI term
			ISI = [ISI_term,zeros(1,length(previous_symbol)-length(ISI_term))];                  
			rs_i = rs_frame(i,:) + ISI;  
			% the ISI term is added to the current OFDM symbol
		else
			rs_i = rs_frame(i,:);
		end;  
		if (mod(i-1,D_t)==0)
			Demodulated_Pilot = PilotSymbolExtractor(rs_i,NFFT,NFFT,G,D_f);			% Trích xuất dữ liệu Pilot dùng cho ướng lượng kênh
			SignalPostFFT = [SignalPostFFT; Demodulated_Pilot];				% Tín hiệu sau khi trích xuất Pilot
			Demodulated_P = [];
			for k = 1:NFFT;
				Demodulated_P = [Demodulated_P; Demodulated_Pilot(k)];
			end;
				estimated_h_i = Q * PP' * Demodulated_P;			% Ước lượng kênh bằng phương pháp LEAST SQUARE ESTIMATION
				he_i = estimated_h_i;
				He_i= fft([he_i;zeros(NFFT-N_P,1)]);
		else
		%-----------------------------------------------------------
		% OFDM demodulator
		%-----------------------------------------------------------
			h_i = h_frame(i,:);
			H_i_ideal = fft([h_i,zeros(1,NFFT-N_P)]);
			Demodulated_signal_i = OFDM_Demodulator(rs_i,NFFT,NFFT,G);  
			SignalPostFFT = [SignalPostFFT; Demodulated_signal_i];
			d_i_e = [];
			d_i_ideal = [];
			for k = 1:NFFT;
				H_k_e = [He_i(k)];
				y = [Demodulated_signal_i(k)];
				x_e = inv(H_k_e) * y;
				d_i_e = [d_i_e,x_e];
				%ideal
				H_k_ideal = [H_i_ideal(k)];
				x_ideal = inv(H_k_ideal) * y;
				d_i_ideal = [d_i_ideal,x_ideal];
			end;
			%--------------------------
			% Demodulated signal 
			%--------------------------
			d_e = [d_e; d_i_e];
			d_ideal = [d_ideal; d_i_ideal];
			demodulated_symbol_i_e = qamdemod(d_i_e,M_ary);
			demodulated_symbol_i_ideal = qamdemod(d_i_ideal,M_ary);
			data_symbol_e = [data_symbol_e, demodulated_symbol_i_e];
			data_symbol_ideal = [data_symbol_ideal, demodulated_symbol_i_ideal];
		end;
		end;
		
		%---------------------------------------------------------------------
		%Chuyển dữ liệu lại thành dữ liệu gốc để so sánh
		%---------------------------------------------------------------------
		data_symbol_e = data_symbol_e';
		bit_data_e = de2bi(data_symbol_e, log2(M_ary));
		bit_data_vector_e = reshape(bit_data_e.', [], 1);
		source_data = reshape(source_data.', [], 1);
		data_symbol_ideal = data_symbol_ideal';
		bit_data = de2bi(data_symbol_ideal, log2(M_ary));
		bit_data_vector = reshape(bit_data.', [], 1);
		[number_without_isic_e, ratio_without_isic_e] = biterr(bit_data_vector_e,source_data);
		[number_without_isic_ideal, ratio_without_isic_ideal] = biterr(bit_data_vector,source_data);
		ber_without_isic_e = [ber_without_isic_e, ratio_without_isic_e];
		ber_without_isic_ideal = [ber_without_isic_ideal, ratio_without_isic_ideal];
	end;
	ber_relz_e = [ber_relz_e;ber_without_isic_e];
	ber_relz_ideal = [ber_relz_ideal;ber_without_isic_ideal];
end;
ber_e = sum(ber_relz_e)/Number_Relz;
ber_ideal = sum(ber_relz_ideal)/Number_Relz;
snr = snr_min:step:snr_max;
semilogy(snr, ber_e,'ro-');
hold on;
semilogy(snr, ber_ideal,'bo-');
legend('LS','Ideal','FontSize',20)
ylabel('BER');
xlabel('SNR');
data_e = [snr; ber_e];