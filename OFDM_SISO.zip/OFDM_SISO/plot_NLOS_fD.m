snr = 0:5:30;
load Ber_NLOS_4fD.mat;
Ber_id_4 = ser_ideal;
Ber_e_4 = ser_e;
load Ber_NLOS_8fD.mat;
Ber_id_8 = ser_ideal;
Ber_e_8 = ser_e;
load Ber_NLOS_16fD.mat;
Ber_id_16 = ser_ideal;
Ber_e_16 = ser_e;
figure(1);

semilogy (snr,Ber_id_4,"-bo",snr,Ber_e_4,"-ro");
hold on;
semilogy (snr,Ber_id_8,"-b*",snr,Ber_e_8,"-r*");
hold on;
semilogy (snr,Ber_id_16,"-b+",snr,Ber_e_16,"-r+");
hold on;
legend('LS, fD_{max} = 4 Hz','Ideal, fD_{max} = 4 Hz','LS, fD_{max} = 8 Hz','Ideal, fD_{max} = 8 Hz', 'LS, fD_{max} = 16 Hz','Ideal, fD_{max} = 16 Hz','FontSize',11);
title ("BER for SISO NLOS channel with 4QAM ")