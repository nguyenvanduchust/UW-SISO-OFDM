load pdp_Halong_150m.mat;

Ni_1 = 40;
Ni_2 = 40;
load x_opt_time_SISO_D_500m.mat;
D = 500; % distance dựa trên file x_opt_time_SISO_D.mat <------ thay đổi ơ đây về khoảng cách
x_suf_1 = x(1:Ni_1);
x_bot_1 = x(Ni_1+1:Ni_2+Ni_1);

y_1 = 0.5;    %<-------------------- khoảng cách với mặt nước so với sensor
y_2 = 1.5;    %<-------------------- khoảng cách với mặt đáy so vơi sensor
c_s = 1500;   %sound speed

teta=2*pi*rand(1,Ni_1+Ni_2+1);
fD = 4;   % Tần số Doppler
B = 500;  % Băng thông
NoSymbol = 10; % Sô lượng symbol phát đi





%% Tín hiệu phát đi
% s =    <------------------ tín hiệu phát đi
%%
SER_R = [];
snr_min =0.0;
snr_max =30.0;
num_repeat = 10;
step = 5;
for snr = snr_min:step:snr_max
SER_t = 0;
    for t_i=1:num_repeat %(1000*1920)
        teta=2*pi*rand(1,Ni_1+Ni_2+1);
        rs_frame = [];
        h_frame = [];
        t = 0.1;
        for i=0:NoSymbol-1
            % Kỹ thuật điều chế ở đây <-----------------------
            [h] = UnderWaterChannel_SISO_LOS(t,teta,D,fD,rho,tau,Ni_1,Ni_2,y_1,y_2,y_1,y_2,x_suf_1,x_bot_1,B);
        end
        rs21 = conv(s, h21);
         %Giải điều chế tín hiệu ở đây <----------------------
         


         % ratio <----------------- tính bit sai ở đây
        SER_t = SER_t + ratio;          
    end
    
        
    tE=SER_t/t_i;
    SER_R = [SER_R, tE]; 
  
end

SER_R_final = SER_R;
snr = snr_min:step:snr_max;

figure(1);
plot(real(d1),imag(d1),'b+'); 
axis([-5 5 -5 5]); 
xlabel('In-phase component of interference cancelled symbols');
ylabel('Quadrature component of interference cancelled symbols'); 

figure(2);
semilogy(snr, SER_R_final,'ro-');
xlabel('SNR in dB');
ylabel('BER');

hold on;
