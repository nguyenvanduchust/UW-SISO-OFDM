function [E]=errorfunc_time_all_SISO(x_i_n)
N_ref_1 = 4000;
N_ref_2 = 4000;
x_i_n_1 = x_i_n(1,1:40);
x_i_n_2 = x_i_n(1,41:80);
y_1=0.5;
y_2=1.5;
D=500;  % khoảng cách cần sửa 
alphav = 2*180*pi/360;
load pdp_Halong_150m.mat;
c_s = 1500;
fD = 4;
p =2;
y_1_T = y_1;
y_1_R = y_1;
y_2_T = y_2;
y_2_R = y_2;
Ni_1 = 40;
Ni_2 = 40;
taumax=9;
tau_d=linspace(0,taumax,800);

x_n_1=linspace(0,D,N_ref_1);
phi_1 = [];
x_n_2 = linspace (0,D,N_ref_2);
phi_2 = [];

for k=1:N_ref_1
    temp1(k) = pi/2+atan((D-x_n_1(k))/(y_1_R)); 
end
phi_1 = [phi_1;temp1];
for k=1:N_ref_2
    temp2(k)= 3*pi/2-atan((D-x_n_2(k))/(y_2_R));
end
phi_2 = [phi_2;temp2];

% suface
temp1=[];
phi_suf = [];
for k=1:Ni_1
    temp1(k) = pi/2+atan((D-x_i_n_1(k))/(y_1_R)); 
end
phi_suf = [phi_suf;temp1];
% bottom
temp2=[];
phi_bot = [];
for k=1:Ni_2
    temp2(k) = 3*pi/2-atan((D-x_i_n_2(k))/(y_2_R)); 
end
phi_bot = [phi_bot;temp2];
int1 = [];
for i=1:length(tau_d)
    D_T = ((y_1_T).^2+ x_n_1.^2).^(1/2);
    D_R = ((y_1_R).^2+ (D-x_n_1).^2).^(1/2);
    D_tau = D_T + D_R;
    tau_1 = D_tau ./c_s;
    c_1 = interpolate_c(rho,tau,tau_1-min(tau_1));
    p_alpha_suf = (y_1_R)./(2*D.*sin(phi_1).^2);
    rr_suf=trapz(phi_1,(c_1.*exp(-sqrt(-1).*2.*pi.*fD.*cos(phi_1-alphav)*tau_d(i)).*p_alpha_suf));

    D_T = ((y_2_T ).^2+ x_n_2.^2).^(1/2);
    D_R = ((y_2_R ).^2+ (D-x_n_2).^2).^(1/2);
    D_tau = D_T + D_R;
    tau_2 = D_tau ./c_s;
    p_alpha_bot = (y_2_R)./(2*D.*sin(phi_2).^2);
    c_2 = interpolate_c(rho,tau,tau_2-min(tau_2));
    rr_bot = trapz(phi_2,c_2.*exp(-sqrt(-1).*2.*pi.*fD.*cos(phi_2-alphav).*tau_d(i)).*p_alpha_bot);

    rr = (-rr_suf + rr_bot);
    sum_suf=0;
    D_T_suf = ((y_1_T).^2+ x_i_n_1.^2).^(1/2);
    D_R_suf = ((y_1_R).^2+ (D-x_i_n_1).^2).^(1/2);
    D_tau_suf = D_T_suf + D_R_suf;
    tau_suf = D_tau_suf ./c_s;
    for n=1:Ni_1
        c_suf = interpolate_c(rho,tau,tau_suf(n)-min(tau_suf));
        sum_suf= sum_suf +c_suf *exp((-1)*sqrt(-1)*2*pi*fD*cos(phi_suf(n)-alphav)*tau_d(i));
    end
    sum_bot = 0;
    D_T_bot = ((y_2_T).^2+ x_i_n_2.^2).^(1/2);
    D_R_bot = ((y_2_R).^2+ (D-x_i_n_2).^2).^(1/2);
    D_tau_bot = D_T_bot + D_R_bot;
    tau_bot = D_tau_bot ./c_s;
    for n=1:Ni_2
        c_bot = interpolate_c(rho,tau,tau_bot(n)-min(tau_bot));
        sum_bot=sum_bot+ c_bot *exp((-1)*sqrt(-1)*2*pi*fD*cos(phi_bot(n)-alphav)*tau_d(i));
    end
    ss=(sum_suf+sum_bot)/(Ni_1+Ni_2);
    int1(i)=(abs(rr-ss))^p;    
end
E=(1/taumax*trapz(tau_d,int1))^(1/p);