clear;
N_ref_1 = 4000;
N_ref_2 = 4000;
Ni_1=40;
Ni_2=40;
fD=4;    % fD = (v_R * f_c)/c_s   with v_R = 1(m/s) and f_c = 12kHz 
y_1=0.5;  % khoảng cách mặt nước
y_2=1.5;  % khoảng cách mặt đáy
alphav=2*pi*180/360; % góc di chuyển của bên thu
p=2;
D=250;  % Sửa giá trị này và giá trị này trong file errorfunc_time_all_SISO
c_s = 1500;
load pdp_Halong_150m.mat;
x_i_n = [];
for n=1:Ni_1
    x_i_n_1(n)=D/Ni_1*(n-1/2);
end
for n=1:Ni_2
    x_i_n_2(n)=D/Ni_2*(n-1/2);
end
x_i_n = [x_i_n_1,x_i_n_2];
options = optimset('Display','iter','TolFun',1*10^(-20),'MaxIter',50,'MaxFunEvals',100000000,'TypicalX',x_i_n,'TolX',1*10^(-20));
x=fminsearch('errorfunc_time_all_SISO',x_i_n,options);   
x_result_time=x;
%save ("x_opt_time_SISO_D_250m.mat","x");

  