function [h] = UnderWaterChannel_SISO_NLOS(t,teta,D,fD,rho,tau,Ni_1,Ni_2,y_1_T,y_2_T,y_1_R,y_2_R,x_suf_1,x_bot_1,B) 
teta_suf = teta(1:Ni_1); % 
teta_bot = teta(Ni_1+1:Ni_1+Ni_2);
alphav = 2*pi*180/360;
c_s = 1500;

% Tinh goc nhan bang x cua toi uu thoi gian
% Surface
phi_1_suf = [];
for k=1:Ni_1
    temp1(k) = pi/2+atan((D-x_suf_1(k))/(y_1_R)); 
end
phi_1_suf = [phi_1_suf;temp1];
% Bottom
temp2=[];
phi_1_bot = [];
for k=1:Ni_2
    temp2(k) = 3*pi/2-atan((D-x_bot_1(k))/(y_2_R)); 
end
phi_1_bot = [phi_1_bot;temp2];

%Surface
i = 1;
D_T = ((y_1_T).^2+ x_suf_1.^2).^(1/2);
D_R = ((y_1_R).^2+ (D-x_suf_1).^2).^(1/2);
D_tau = D_T + D_R;
tau_suf = D_tau ./c_s; 
for n = 1 : Ni_1
    fn = fD*cos(phi_1_suf(n)-alphav);
    c = interpolate_c(rho,tau,tau_suf(n)-min(tau_suf));
    h_suf(n) =  sqrt(c)*exp(sqrt(-1)*(2*pi*fn*t+teta_suf(n)))/sqrt(Ni_1+Ni_2);
end
%bottom
i=2;
D_T = ((y_2_T).^2+ x_bot_1.^2).^(1/2);
D_R = ((y_2_R).^2+ (D-x_bot_1).^2).^(1/2);
D_tau = D_T + D_R;
tau_bot = D_tau ./c_s;
for n = 1 : Ni_2
    fn = fD*cos(phi_1_bot(n)-alphav);
    c = interpolate_c(rho,tau,tau_bot(n)-min(tau_bot));
    h_bot(n) =  sqrt(c)*exp(sqrt(-1)*(2*pi*fn*t+teta_bot(n)))/sqrt(Ni_1+Ni_2);
end
tau_all = [tau_suf,tau_bot];
h_all = [h_suf,h_bot];
min_tau_all = min(tau_all);
tau_all_after = tau_all - min_tau_all;
max_index = round(max(tau_all_after)/(1/B));
% Quy đáp ứng xung về thời gian lấy mẫu
h=[];

for k = 1 : max_index+1
    h(k)=0;
    for m = 1:(Ni_1+Ni_2)
        if (round(tau_all_after(m)/(1/B)) == k-1)
            h(k) = h_all(m)+h(k);
        end
    end
end
   

