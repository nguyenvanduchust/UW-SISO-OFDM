function [c_new] = interpolate_c(rho,tau,tau_new)
c_new = interp1(tau,rho,tau_new);
